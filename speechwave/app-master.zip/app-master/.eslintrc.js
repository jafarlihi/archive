module.exports = require("@blitzjs/next/eslint");
