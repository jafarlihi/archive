-- AlterTable
ALTER TABLE "Upload" DROP COLUMN "enhancementStatus",
DROP COLUMN "summarizationStatus",
DROP COLUMN "transcriptionStatus",
DROP COLUMN "translationStatus";
