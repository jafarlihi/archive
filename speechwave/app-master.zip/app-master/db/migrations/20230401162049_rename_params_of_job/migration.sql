/*
  Warnings:

  - You are about to drop the column `params` on the `Job` table. All the data in the column will be lost.
  - Changed the type of `status` on the `Job` table. No cast exists, the column would be dropped and recreated, which cannot be done if there is data, since the column is required.
  - Changed the type of `type` on the `Job` table. No cast exists, the column would be dropped and recreated, which cannot be done if there is data, since the column is required.
  - Changed the type of `type` on the `Token` table. No cast exists, the column would be dropped and recreated, which cannot be done if there is data, since the column is required.

*/
-- AlterTable
ALTER TABLE "Job" DROP COLUMN "params",
ADD COLUMN     "parameters" JSONB,
DROP COLUMN "status",
ADD COLUMN     "status" "ProcessStatus" NOT NULL,
DROP COLUMN "type",
ADD COLUMN     "type" "ProcessType" NOT NULL;

-- AlterTable
ALTER TABLE "Token" DROP COLUMN "type",
ADD COLUMN     "type" "TokenType" NOT NULL;

-- CreateIndex
CREATE UNIQUE INDEX "Token_hashedToken_type_key" ON "Token"("hashedToken", "type");
