import { resolver } from "@blitzjs/rpc";
import { z } from "zod";
import crypto from "crypto";
import db from "db";

const CreateApiKey = z.object({
  name: z.string().optional(),
});

export default resolver.pipe(
  resolver.zod(CreateApiKey),
  resolver.authorize(),
  async (input, ctx) => {
    const token = crypto.randomBytes(32).toString("base64");

    const apiKey = await db.apiKey.create({
      data: {
        name: input.name,
        userId: ctx.session.userId,
        token,
      },
    });

    return apiKey;
  }
);
