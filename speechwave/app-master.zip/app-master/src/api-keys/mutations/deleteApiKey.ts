import { resolver } from "@blitzjs/rpc";
import db from "db";
import { z } from "zod";

const DeleteApiKey = z.object({
  id: z.string(),
});

export default resolver.pipe(
  resolver.zod(DeleteApiKey),
  resolver.authorize(),
  async ({ id }, ctx) => {
    const apiKey = await db.apiKey.deleteMany({
      where: {
        id,
        userId: ctx.session.userId,
      },
    });

    return apiKey;
  }
);
