import { NotFoundError } from "blitz";
import { resolver } from "@blitzjs/rpc";
import db from "db";
import { z } from "zod";

const GetApiKey = z.object({
  id: z.string(),
});

export default resolver.pipe(
  resolver.zod(GetApiKey),
  resolver.authorize(),
  async ({ id }, ctx) => {
    const apiKey = await db.apiKey.findFirst({
      where: { id, userId: ctx.session.userId },
    });

    if (!apiKey) throw new NotFoundError();

    return apiKey;
  }
);
