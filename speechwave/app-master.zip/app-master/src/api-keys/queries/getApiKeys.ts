import { paginate } from "blitz";
import { resolver } from "@blitzjs/rpc";
import db, { Prisma } from "db";

interface GetApiKeysInput
  extends Pick<Prisma.ApiKeyFindManyArgs, "orderBy" | "skip" | "take"> {}

export default resolver.pipe(
  resolver.authorize(),
  async ({ orderBy, skip = 0, take = 250 }: GetApiKeysInput, ctx) => {
    const where = {
      userId: ctx.session.userId,
    };

    const {
      items: apiKeys,
      hasMore,
      nextPage,
      count,
    } = await paginate({
      skip,
      take,
      count: () => db.apiKey.count({ where }),
      query: (paginateArgs) =>
        db.apiKey.findMany({ ...paginateArgs, where, orderBy }),
    });

    return {
      apiKeys,
      nextPage,
      hasMore,
      count,
    };
  }
);
