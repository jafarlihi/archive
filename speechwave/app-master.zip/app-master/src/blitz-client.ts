import { AuthClientPlugin } from "@blitzjs/auth";
import { setupBlitzClient } from "@blitzjs/next";
import { BlitzRpcPlugin } from "@blitzjs/rpc";
import { APP_NAME } from "src/core/constants";

export const authConfig = {
  cookiePrefix: APP_NAME,
};

export const { withBlitz } = setupBlitzClient({
  plugins: [AuthClientPlugin(authConfig), BlitzRpcPlugin({})],
});
