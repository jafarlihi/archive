import { useState } from "react";
import { useMutation, useQuery } from "@blitzjs/rpc";
import {
  Col,
  Grid,
  Input,
  Modal,
  Popover,
  Row,
  Table,
  Tooltip,
} from "@nextui-org/react";
import { Text, Button, Spacer } from "@nextui-org/react";
import { AiOutlineCheck, AiOutlineDelete, AiOutlinePlus } from "react-icons/ai";
import { HiOutlineClipboardCheck } from "react-icons/hi";
import createApiKey from "src/api-keys/mutations/createApiKey";
import deleteApiKey from "src/api-keys/mutations/deleteApiKey";
import getApiKeys from "src/api-keys/queries/getApiKeys";
import { IconButton } from "src/styles/IconButton";
import { copyToClipboard } from "src/core/utils";

const APIKeyCell = (props: { item: any; columnKey: any; deleteKey: any }) => {
  const [popoverOpen, setPopoverOpen] = useState(false);

  switch (props.columnKey) {
    case "createdAt":
      return props.item.createdAt.toLocaleDateString();
    case "actions":
      return (
        <Row justify="center" align="center">
          <Col css={{ d: "flex" }}>
            <Tooltip
              content="Copy to clipboard"
              color="primary"
              css={{ zIndex: "99999" }}
            >
              <Popover>
                <Popover.Trigger>
                  <IconButton onClick={() => copyToClipboard(props.item.token)}>
                    <HiOutlineClipboardCheck
                      size={20}
                      stroke={"var(--nextui-colors-primary)"}
                    />
                  </IconButton>
                </Popover.Trigger>
                <Popover.Content>
                  <Row
                    style={{ padding: "10px" }}
                    justify="center"
                    align="center"
                  >
                    <AiOutlineCheck color={"var(--nextui-colors-primary)"} />
                    &nbsp;&nbsp;<Text color="primary">Copied!</Text>
                  </Row>
                </Popover.Content>
              </Popover>
            </Tooltip>
            <Tooltip content="Delete" color="error" css={{ zIndex: "99999" }}>
              <Popover isOpen={popoverOpen} onOpenChange={setPopoverOpen}>
                <Popover.Trigger>
                  <IconButton>
                    <AiOutlineDelete size={20} fill="#FF0080" />
                  </IconButton>
                </Popover.Trigger>
                <Popover.Content>
                  <Grid.Container
                    css={{
                      borderRadius: "14px",
                      padding: "0.75rem",
                      maxWidth: "330px",
                    }}
                  >
                    <Row justify="center" align="center">
                      <Text b>Confirm</Text>
                    </Row>
                    <Row>
                      <Text>Are you sure you want to delete this API key?</Text>
                    </Row>
                    <Grid.Container
                      justify="space-between"
                      alignContent="center"
                    >
                      <Grid>
                        <Button
                          size="sm"
                          light
                          onPress={() => setPopoverOpen(false)}
                        >
                          Cancel
                        </Button>
                      </Grid>
                      <Grid>
                        <Button
                          size="sm"
                          shadow
                          color="error"
                          onPress={() => props.deleteKey(props.item.id)}
                        >
                          Delete
                        </Button>
                      </Grid>
                    </Grid.Container>
                  </Grid.Container>
                </Popover.Content>
              </Popover>
            </Tooltip>
          </Col>
        </Row>
      );
    case "token":
      return <Text size={12}>{props.item[props.columnKey]}</Text>;
    case "name":
      return props.item[props.columnKey];
  }
};

export default function APIKeyModal(props: {
  visible: boolean;
  closeHandler: () => void;
}) {
  const [{ apiKeys }, { refetch }] = useQuery(getApiKeys, {
    orderBy: {
      createdAt: "desc",
    },
  });
  const [createApiKeyMutation] = useMutation(createApiKey);
  const [deleteApiKeyMutation] = useMutation(deleteApiKey);
  const [name, setName] = useState("");

  const createKey = async () => {
    await createApiKeyMutation({ name });
    setName("");
    await refetch();
  };

  const deleteKey = async (id: number) => {
    await deleteApiKeyMutation({ id });
    await refetch();
  };

  const columns = [
    {
      key: "name",
      label: "Name",
    },
    {
      key: "createdAt",
      label: "Creation Date",
    },
    {
      key: "token",
      label: "Key",
    },
    {
      key: "actions",
      label: "Actions",
    },
  ];

  return (
    <Modal
      closeButton
      aria-labelledby="API keys modal"
      open={props.visible}
      onClose={() => {
        setName("");
        props.closeHandler();
      }}
      width="800px"
    >
      <Modal.Header>
        <Text id="modal-title" size={18}>
          API Keys
        </Text>
      </Modal.Header>
      <Modal.Body>
        <Row justify="center" align="center">
          <Input
            bordered
            placeholder="Name"
            value={name}
            onChange={(e) => setName(e.target.value)}
          />
          <Spacer x={1} />
          <Button
            color="primary"
            ghost
            iconRight={<AiOutlinePlus />}
            onPress={createKey}
          >
            Create
          </Button>
        </Row>
        <Table
          aria-label="API keys table"
          css={{
            height: "auto",
            minWidth: "100%",
          }}
        >
          <Table.Header columns={columns}>
            {(column) => (
              <Table.Column key={column.key}>{column.label}</Table.Column>
            )}
          </Table.Header>
          <Table.Body items={apiKeys}>
            {(item) => (
              <Table.Row key={item.id}>
                {(columnKey) => (
                  <Table.Cell>
                    <APIKeyCell
                      item={item}
                      columnKey={columnKey}
                      deleteKey={deleteKey}
                    />
                  </Table.Cell>
                )}
              </Table.Row>
            )}
          </Table.Body>
        </Table>
      </Modal.Body>
      <Modal.Footer>
        <Button
          auto
          flat
          color="error"
          onPress={() => {
            setName("");
            props.closeHandler();
          }}
        >
          Close
        </Button>
      </Modal.Footer>
    </Modal>
  );
}
