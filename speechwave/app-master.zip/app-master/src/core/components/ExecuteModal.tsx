import { useEffect, useState } from "react";
import {
  Modal,
  Col,
  Row,
  Text,
  Checkbox,
  Spacer,
  Badge,
  Button,
} from "@nextui-org/react";
import { ProcessType, Upload } from "@prisma/client";
import Select from "react-select";
import makeAnimated from "react-select/animated";
import { MdNavigateNext } from "react-icons/md";
import { RiCoinsLine } from "react-icons/ri";
import { BsChatText, BsMagic } from "react-icons/bs";
import { HiOutlineTranslate } from "react-icons/hi";
import { FiFileText } from "react-icons/fi";
import { LANGUAGES, CREDIT_COST } from "../constants";
import { shortEnglishDurationHumanizer } from "../utils";
import SVGLinearGradient from "./SVGLinearGradient";

type Language = {
  value: string;
  label: string;
};

// TODO: Show info about skipped jobs because appropriate status job is already there
export default function ExecuteModal(props: any) {
  const animatedComponents = makeAnimated();

  const [selectedServices, setSelectedServices] = useState<string[]>([]);
  const [cost, setCost] = useState(0); // TODO: Round to 1 if 0 here and in backend
  const [translateLanguages, setTranslateLanguages] = useState<Language[]>([]);
  const [summarizeLanguages, setSummarizeLanguages] = useState<Language[]>([]);

  useEffect(() => {
    if (
      selectedServices.includes("translate") ||
      selectedServices.includes("summarize")
    ) {
      if (!selectedServices.includes("transcribe")) {
        setSelectedServices((prev) => [...prev, "transcribe"]);
      }
    }
  }, [selectedServices]);

  useEffect(() => {
    let totalCost = 0;
    if (selectedServices.includes("transcribe")) {
      // TODO: Filter props.selected where job in appropriate status is already there
      const runtime = props.selected
        .map((s: Upload) => s.length)
        .reduce((p: number, n: number) => p + n, 0);
      totalCost += runtime / CREDIT_COST.get(ProcessType.TRANSCRIPTION)!;
    }
    if (selectedServices.includes("translate")) {
      const runtime = props.selected
        .map((s: Upload) => s.length)
        .reduce((p: number, n: number) => p + n, 0);
      totalCost +=
        (runtime / CREDIT_COST.get(ProcessType.TRANSLATION)!) *
        translateLanguages.length;
    }
    if (selectedServices.includes("enhance")) {
      const runtime = props.selected
        .map((s: Upload) => s.length)
        .reduce((p: number, n: number) => p + n, 0);
      totalCost += runtime / CREDIT_COST.get(ProcessType.ENHANCEMENT)!;
    }
    if (selectedServices.includes("summarize")) {
      const runtime = props.selected
        .map((s: Upload) => s.length)
        .reduce((p: number, n: number) => p + n, 0);
      totalCost +=
        (runtime / CREDIT_COST.get(ProcessType.SUMMARIZATION)!) *
        summarizeLanguages.length;
    }
    setCost(Math.round(totalCost));
  }, [
    selectedServices,
    props.selected,
    translateLanguages,
    summarizeLanguages,
  ]);

  const closeHandler = () => {
    setSelectedServices([]);
    setTranslateLanguages([]);
    setSummarizeLanguages([]);
    props.setVisible(false);
  };
  const transcribe = async (upload: Upload) => {
    // TODO: Create Job
  };
  const translate = async (upload: Upload) => {
    // TODO: Create Job
  };
  const execute = async () => {
    for (const s of props.selected) {
      if (selectedServices.includes("transcribe")) {
        await transcribe(s);
      }
      if (selectedServices.includes("translate")) {
        await translate(s);
      }
    }
    props.setSelected([]);
    closeHandler();
  };
  const onTranscribeCheckboxChange = (value: boolean) => {
    if (!value) {
      setSelectedServices((prev) => {
        return prev.filter((s) => s !== "translate" && s !== "summarize");
      });
    }
  };

  const getHeadlineText = () => {
    return `${props.selected.length} upload${
      props.selected.length > 1 ? "s" : ""
    } selected | ${shortEnglishDurationHumanizer(
      props.selected
        .map((s) => s.length)
        .reduce((p: number, n: number) => p + n, 0)
    )} total runtime`;
  };
  const getTranslateLanguageSelect = () => {
    if (selectedServices.includes("translate"))
      return (
        <div
          style={{
            width: "400px",
            position: "absolute",
            left: "350px",
          }}
        >
          <Select
            closeMenuOnSelect={false}
            components={animatedComponents}
            defaultValue={[]}
            isMulti
            options={LANGUAGES}
            placeholder="Select languages"
            onChange={setTranslateLanguages}
          />
        </div>
      );
    else return <></>;
  };
  const getSummarizeLanguageSelect = () => {
    if (selectedServices.includes("summarize"))
      return (
        <div
          style={{
            width: "400px",
            position: "absolute",
            left: "350px",
          }}
        >
          <Select
            closeMenuOnSelect={false}
            components={animatedComponents}
            defaultValue={[]}
            isMulti
            options={LANGUAGES}
            placeholder="Select languages"
            onChange={setSummarizeLanguages}
          />
        </div>
      );
    else return <></>;
  };

  return (
    <>
      <SVGLinearGradient />
      <Modal
        closeButton
        aria-labelledby="Process execution modal"
        open={props.visible}
        onClose={closeHandler}
        width="800px"
        css={{ height: "600px" }}
      >
        <Modal.Body>
          <Col align="center" style={{ width: "100%" }}>
            <Text
              h1
              size={18}
              css={{
                textGradient: "45deg, $blue600 -20%, $pink600 50%",
              }}
              weight="bold"
            >
              {getHeadlineText()}
            </Text>
            <Row align="center" style={{ width: "100%" }}>
              <Checkbox.Group
                color="secondary"
                value={selectedServices}
                onChange={setSelectedServices}
                style={{ width: "100%" }}
              >
                <Spacer y={1} />
                <Row>
                  <Checkbox
                    onChange={onTranscribeCheckboxChange}
                    isSelected={selectedServices.includes("transcribe")}
                    color="gradient"
                    value="transcribe"
                  >
                    <BsChatText
                      style={{ fontSize: "16px", fill: "url(#blue-gradient)" }}
                    />
                    <Spacer x={0.2} /> Transcribe
                  </Checkbox>
                </Row>
                <Spacer y={1} />
                <Row>
                  <Checkbox color="gradient" value="translate">
                    <HiOutlineTranslate
                      style={{
                        fontSize: "16px",
                        stroke: "url(#blue-gradient)",
                      }}
                    />
                    <Spacer x={0.2} /> Translate
                  </Checkbox>
                  <div>{getTranslateLanguageSelect()}</div>
                </Row>
                <Spacer y={1} />
                <Row>
                  <Checkbox color="gradient" value="enhance">
                    <BsMagic
                      style={{ fontSize: "16px", fill: "url(#blue-gradient)" }}
                    />
                    <Spacer x={0.2} /> Enhance
                  </Checkbox>
                </Row>
                <Spacer y={1} />
                <Row>
                  <Checkbox color="gradient" value="summarize">
                    <FiFileText
                      style={{
                        fontSize: "16px",
                        stroke: "url(#blue-gradient)",
                      }}
                    />
                    <Spacer x={0.2} /> Summarize
                  </Checkbox>
                  <div>{getSummarizeLanguageSelect()}</div>
                </Row>
                <Spacer y={1} />
              </Checkbox.Group>
            </Row>
          </Col>
        </Modal.Body>
        <Modal.Footer>
          <Badge color="secondary" variant="flat" size="lg">
            <RiCoinsLine />
            &nbsp; {cost} credits
          </Badge>
          <Button auto flat color="error" onPress={closeHandler}>
            Close
          </Button>
          <Button
            auto
            onPress={async () => {
              await execute();
              closeHandler();
            }}
          >
            Execute <MdNavigateNext size="24" />
          </Button>
        </Modal.Footer>
      </Modal>
    </>
  );
}
