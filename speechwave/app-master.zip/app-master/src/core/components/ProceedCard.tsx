import {
  Card,
  Text,
  Spacer,
  Button,
  Tooltip,
  Popover,
  Grid,
  Row,
} from "@nextui-org/react";
import { useState } from "react";
import { AiOutlineDelete } from "react-icons/ai";
import { MdNavigateNext } from "react-icons/md";
import { IconButton } from "src/styles/IconButton";

export default function ProceedCard(props: any) {
  const [deletePopoverOpen, setDeletePopoverOpen] = useState(false);

  return (
    <>
      {props.selected.length > 0 && (
        <Card
          style={{
            width: "100%",
            marginBottom: "10px",
            paddingLeft: "20px",
          }}
        >
          <Card.Body style={{ position: "relative" }}>
            <div
              style={{
                display: "flex",
                justifyContent: "center",
                alignItems: "baseline",
              }}
            >
              <Text
                h1
                size={18}
                css={{
                  textGradient: "45deg, $blue600 -20%, $pink600 50%",
                }}
                weight="bold"
              >
                {props.selected.length} upload{props.selected.length > 1 && "s"}{" "}
                selected
              </Text>
              <Spacer x={1} />
              <Button
                color="gradient"
                style={{ fontSize: "16px", fontWeight: "800" }}
                onPress={props.onProceedClick}
              >
                Proceed <MdNavigateNext size="24" />
              </Button>
              <div
                style={{
                  position: "absolute",
                  right: "20px",
                  top: "37%",
                }}
              >
                <Tooltip
                  content="Delete"
                  color="error"
                  css={{ zIndex: "99999" }}
                >
                  <Popover
                    isOpen={deletePopoverOpen}
                    onOpenChange={setDeletePopoverOpen}
                  >
                    <Popover.Trigger>
                      <IconButton>
                        <AiOutlineDelete size={24} fill="#FF0080" />
                      </IconButton>
                    </Popover.Trigger>
                    <Popover.Content>
                      <Grid.Container
                        css={{
                          borderRadius: "14px",
                          padding: "0.75rem",
                          maxWidth: "330px",
                        }}
                      >
                        <Row justify="center" align="center">
                          <Text b>Confirm</Text>
                        </Row>
                        <Row>
                          <Text>
                            Are you sure you want to delete the selected
                            uploads?
                          </Text>
                        </Row>
                        <Grid.Container
                          justify="space-between"
                          alignContent="center"
                        >
                          <Grid>
                            <Button
                              size="sm"
                              light
                              onPress={() => setDeletePopoverOpen(false)}
                            >
                              Cancel
                            </Button>
                          </Grid>
                          <Grid>
                            <Button
                              size="sm"
                              shadow
                              color="error"
                              onPress={async () => {
                                await props.deleteUploads(props.selected);
                                setDeletePopoverOpen(false);
                              }}
                            >
                              Delete
                            </Button>
                          </Grid>
                        </Grid.Container>
                      </Grid.Container>
                    </Popover.Content>
                  </Popover>
                </Tooltip>
              </div>
            </div>
          </Card.Body>
        </Card>
      )}
    </>
  );
}
