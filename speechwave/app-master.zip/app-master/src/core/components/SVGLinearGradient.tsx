export default function SVGLinearGradient(_props: any) {
  return (
    <svg width="0" height="0">
      <linearGradient id="blue-gradient" x1="100%" y1="100%" x2="0%" y2="0%">
        <stop stopColor="var(--nextui-colors-blue600)" offset="0%" />
        <stop stopColor="var(--nextui-colors-red600)" offset="100%" />
      </linearGradient>
    </svg>
  );
}
