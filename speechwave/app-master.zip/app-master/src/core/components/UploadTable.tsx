import { Button, Row, Spacer, Table } from "@nextui-org/react";
import { Upload } from "@prisma/client";
import { Key } from "react";
import { MdNavigateNext } from "react-icons/md";
import { shortEnglishDurationHumanizer, truncate } from "../utils";

export default function UploadTable(props: any) {
  const columns = [
    {
      key: "name",
      label: "Upload Name",
    },
    {
      key: "length",
      label: "Length",
    },
    {
      key: "createdAt",
      label: "Upload Date",
    },
    {
      key: "actions",
      label: "Actions",
    },
  ];

  const onSelectionChange = (selected: Set<Key> | string) => {
    if (typeof selected !== "string")
      props.setSelected(
        props.uploads.filter((u: Upload) => Array.from(selected).includes(u.id))
      );
    else if (selected === "all") props.setSelected(props.uploads);
  };

  const getActionButtons = (upload: Upload) => {
    return (
      <Row>
        <Button ghost color="primary" auto style={{ width: "30%" }}>
          Results
        </Button>
        <Spacer x={0.5} />
        <Button
          ghost
          color="gradient"
          auto
          style={{ width: "70%" }}
          onPress={() => {
            props.setSelected([upload]);
            props.onProceedClick();
          }}
        >
          Proceed <MdNavigateNext size="24" />
        </Button>
      </Row>
    );
  };

  const getColumnLabel = (column: any) => {
    return column.label;
  };

  const getRowValue = (upload: Upload, columnKey: any) => {
    if (columnKey === "name") return truncate(upload[columnKey], 80);
    else if (columnKey === "createdAt")
      return upload.createdAt.toLocaleDateString();
    else if (columnKey === "length")
      return shortEnglishDurationHumanizer(upload[columnKey]);
    else if (columnKey === "actions") return getActionButtons(upload);
    else return upload[columnKey];
  };

  return (
    <Table
      aria-label="Uploads table"
      color={"primary"}
      selectionMode="multiple"
      containerCss={{ height: "auto", minWidth: "100%" }}
      onSelectionChange={onSelectionChange}
      selectedKeys={props.selected.map((u: Upload) => u.id)}
    >
      <Table.Header columns={columns}>
        {(column) => (
          <Table.Column key={column.key}>{getColumnLabel(column)}</Table.Column>
        )}
      </Table.Header>
      <Table.Body>
        {props.uploads.map((u: Upload) => (
          <Table.Row key={u.id}>
            {(columnKey) => (
              <Table.Cell>{getRowValue(u, columnKey)}</Table.Cell>
            )}
          </Table.Row>
        ))}
      </Table.Body>
    </Table>
  );
}
