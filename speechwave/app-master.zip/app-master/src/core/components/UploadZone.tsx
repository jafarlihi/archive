import { useCallback, useState } from "react";
import { getAntiCSRFToken } from "@blitzjs/auth";
import { Card, Col, Row, Text, Progress } from "@nextui-org/react";
import { AiOutlineCloudUpload } from "react-icons/ai";
import { useDropzone } from "react-dropzone";
import axios from "axios";
import SVGLinearGradient from "./SVGLinearGradient";

export default function UploadZone(props: any) {
  const [progress, setProgress] = useState(0);
  const antiCSRFToken = getAntiCSRFToken();
  const onDrop = useCallback(
    (acceptedFiles: File[]) => {
      const formData = new FormData();
      for (const file of acceptedFiles) formData.append("files", file);
      axios
        .request({
          method: "post",
          url: "api/upload",
          data: formData,
          headers: {
            "Content-Type": "multipart/form-data",
            "Anti-CSRF": antiCSRFToken,
          },
          onUploadProgress: (p) => {
            setProgress(p.loaded / (p.total || 0));
          },
        })
        .then(async (data) => {
          setProgress(0);
          await props?.onSuccess?.(data);
        })
        .catch(async (error) => {
          await props?.onError?.(error);
        });
    },
    [props, antiCSRFToken]
  );
  const { getRootProps, getInputProps } = useDropzone({
    onDrop,
  });

  return (
    <>
      <SVGLinearGradient />
      <Card
        style={{
          height: progress === 0 ? "112px" : "130px",
          width: "100%",
          cursor: "pointer",
        }}
        variant="bordered"
      >
        <div
          {...getRootProps({ className: "dropzone" })}
          style={{ width: "100%", height: "100%", padding: "10px" }}
        >
          <input {...getInputProps()} />
          <Col align="center">
            <AiOutlineCloudUpload
              size="50"
              style={{ fill: "url(#blue-gradient)" }}
            />
            <Row justify="center" align="center">
              <Text
                h1
                size={20}
                css={{
                  textGradient: "45deg, $blue600 -20%, $red600 100%",
                }}
                weight="bold"
              >
                Drag and drop audio or video files here or click to browse.
              </Text>
            </Row>
          </Col>
          {progress > 0 && <Progress color="primary" value={progress} />}
        </div>
      </Card>
    </>
  );
}
