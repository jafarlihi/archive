import { useState } from "react";
import { Dropdown, useTheme } from "@nextui-org/react";
import { Button, Spacer } from "@nextui-org/react";
import { BsKey } from "react-icons/bs";
import { BiCartAlt } from "react-icons/bi";
import { AiOutlineApi } from "react-icons/ai";
import { FiFileText } from "react-icons/fi";
import { useCurrentUser } from "src/users/hooks/useCurrentUser";
import APIKeyModal from "../components/APIKeyModal";

export default function UserButtons(_props: any) {
  const currentUser = useCurrentUser();
  const { theme } = useTheme();
  const [apiKeyModalVisible, setApiKeyModalVisible] = useState(false);
  const apiKeyModalHandler = () => setApiKeyModalVisible(true);
  const apiKeyModalCloseHandler = () => {
    setApiKeyModalVisible(false);
  };

  if (!currentUser) return <></>;
  return (
    <>
      <div
        style={{
          borderLeft: "1px solid " + theme!.colors.gray300.value,
          height: "100%",
        }}
      ></div>
      <APIKeyModal
        visible={apiKeyModalVisible}
        closeHandler={apiKeyModalCloseHandler}
      />
      <div style={{ display: "flex", alignItems: "center" }}>
        <Button
          iconRight={<BiCartAlt fill="currentColor" />}
          color="primary"
          auto
          flat
          size="sm"
          onClick={async () => {}}
        >
          Buy credits
        </Button>
        <Spacer x={0.5} />
        <Dropdown>
          <Dropdown.Button
            iconRight={<AiOutlineApi fill="currentColor" />}
            color="primary"
            auto
            flat
            size="sm"
          >
            API
          </Dropdown.Button>
          <Dropdown.Menu
            color="primary"
            aria-label="Actions"
            css={{ $$dropdownMenuWidth: "280px" }}
            onAction={(key) => {
              if (key === "keys") apiKeyModalHandler();
            }}
          >
            <Dropdown.Item
              key="keys"
              description="Manage API keys"
              icon={<BsKey size={22} fill="var(--nextui-colors-primary)" />}
            >
              Keys
            </Dropdown.Item>
            <Dropdown.Item
              key="docs"
              description="Read the API documentation"
              icon={
                <FiFileText size={22} stroke="var(--nextui-colors-primary)" />
              }
            >
              Docs
            </Dropdown.Item>
          </Dropdown.Menu>
        </Dropdown>
      </div>
      <div
        style={{
          borderLeft: "1px solid " + theme!.colors.gray300.value,
          height: "100%",
        }}
      ></div>
    </>
  );
}
