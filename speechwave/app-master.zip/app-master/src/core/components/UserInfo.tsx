import { Badge, Spacer } from "@nextui-org/react";
import { useCurrentUser } from "src/users/hooks/useCurrentUser";

export default function UserInfo(_props: any) {
  const currentUser = useCurrentUser();

  if (!currentUser) return <></>;
  return (
    <div style={{ display: "flex", alignItems: "center" }}>
      <Badge isSquared color="primary" variant="bordered">
        {currentUser?.email}
      </Badge>
      <Spacer x={0.5} />
      <Badge isSquared color="primary" variant="bordered">
        {currentUser?.credits} credits
      </Badge>
    </div>
  );
}
