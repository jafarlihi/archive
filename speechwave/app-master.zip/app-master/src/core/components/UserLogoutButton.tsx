import { useRouter } from "next/router";
import { useMutation } from "@blitzjs/rpc";
import { Button } from "@nextui-org/react";
import { BiLogOut } from "react-icons/bi";
import { useCurrentUser } from "src/users/hooks/useCurrentUser";
import logout from "src/auth/mutations/logout";

export default function UserLogoutButton(_props: any) {
  const currentUser = useCurrentUser();
  const router = useRouter();
  const [logoutMutation] = useMutation(logout);

  if (!currentUser) return <></>;
  return (
    <div style={{ display: "flex", alignItems: "center" }}>
      <Button
        iconRight={
          <BiLogOut
            fill="currentColor"
            style={{ transform: "rotate(180deg)" }}
          />
        }
        color="error"
        auto
        flat
        size="sm"
        onClick={async () => {
          await logoutMutation();
          await router.push("/");
        }}
      >
        Log out
      </Button>
    </div>
  );
}
