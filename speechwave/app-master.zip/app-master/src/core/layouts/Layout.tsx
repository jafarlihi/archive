import React, { Suspense } from "react";
import Head from "next/head";
import { useRouter } from "next/router";
import { BlitzLayout } from "@blitzjs/next";
import { Switch, useTheme } from "@nextui-org/react";
import { Text, Navbar, Button, Spacer } from "@nextui-org/react";
import { useTheme as useNextTheme } from "next-themes";
import { BsSun, BsMoon } from "react-icons/bs";
import { APP_NAME } from "../constants";
import UserInfo from "../components/UserInfo";
import UserLogoutButton from "../components/UserLogoutButton";
import UserButtons from "../components/UserButtons";

const Layout: BlitzLayout<{ title?: string; children?: React.ReactNode }> = ({
  title,
  children,
}) => {
  const { setTheme } = useNextTheme();
  const { isDark, theme } = useTheme();
  const router = useRouter();
  const isApp = router.pathname.startsWith("/app");

  return (
    <div>
      <Head>
        <title>{title || APP_NAME}</title>
        <link rel="icon" href="/favicon.ico" />
      </Head>
      <Navbar isCompact variant="static" maxWidth="fluid">
        <Navbar.Brand hideIn={"xs"}>
          <Text
            b
            color="inherit"
            onClick={async () => await router.push("/")}
            style={{ cursor: "pointer" }}
          >
            {APP_NAME}
          </Text>
          <Spacer x={2} />
          {isApp && (
            <Suspense>
              <UserInfo />
            </Suspense>
          )}
        </Navbar.Brand>
        <Navbar.Content>
          <Switch
            icon={!isDark ? <BsSun /> : <BsMoon />}
            checked={isDark}
            onChange={(e) => setTheme(e.target.checked ? "dark" : "light")}
          />
          {isApp ? (
            <>
              <Suspense>
                <UserButtons />
              </Suspense>
              <Suspense>
                <UserLogoutButton />
              </Suspense>
            </>
          ) : (
            <Button
              color="gradient"
              ghost
              shadow
              size="sm"
              onPress={async () => await router.push("/app")}
            >
              Enter App
            </Button>
          )}
        </Navbar.Content>
      </Navbar>
      <div>
        <Suspense>
          {React.cloneElement(children as React.ReactElement, { theme })}
        </Suspense>
      </div>
    </div>
  );
};

export default Layout;
