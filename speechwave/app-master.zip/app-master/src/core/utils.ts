import { NextApiRequest, NextApiResponse } from "next";
import { Ctx } from "blitz";
import db from "db";
import { Role } from "types";
import humanizeDuration from "humanize-duration";

export const copyToClipboard = (content: any) => {
  const el = document.createElement("textarea");
  el.value = content;
  document.body.appendChild(el);
  el.select();
  document.execCommand("copy");
  document.body.removeChild(el);
};

export const truncate = (str: string, n: number) => {
  return str.length > n ? str.slice(0, n - 1) + "..." : str;
};

export const shortEnglishDurationHumanizer = humanizeDuration.humanizer({
  language: "shortEn",
  languages: {
    shortEn: {
      y: () => "y",
      mo: () => "mo",
      w: () => "w",
      d: () => "d",
      h: () => "h",
      m: () => "m",
      s: () => "s",
      ms: () => "ms",
    },
  },
});

export const verifyToken = async (
  req: NextApiRequest,
  res: NextApiResponse,
  ctx: Ctx,
  userId: string | number | undefined,
  returnOnly = false
) => {
  let authorization = req.headers.authorization;
  if (!authorization)
    return res.status(401).json({ error: "No token provided" });
  authorization = authorization.replace(/bearer /i, "");
  const token = await db.apiKey.findFirst({
    where: {
      token: authorization,
    },
    include: {
      user: true,
    },
  });
  if (
    !token ||
    (userId === -1 && !token.user.role.includes("ADMIN")) ||
    (userId && token.userId !== userId && !token.user.role.includes("ADMIN"))
  )
    return res.status(403).json({ error: "Wrong credentials" });
  if (returnOnly)
    return { userId: token.user.id, role: token.user.role as Role };
  await ctx.session.$create({
    userId: token.user.id,
    role: token.user.role as Role,
  });
  return true;
};
