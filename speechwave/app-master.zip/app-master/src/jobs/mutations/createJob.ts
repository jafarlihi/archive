import { resolver } from "@blitzjs/rpc";
import { AuthorizationError, NotFoundError } from "blitz";
import db, { ProcessStatus, ProcessType } from "db";
import { CREDIT_COST } from "src/core/constants";
import { z } from "zod";

const CreateJob = z.object({
  uploadId: z.string(),
  type: z.nativeEnum(ProcessType),
  parameters: z.any().optional(),
});

export default resolver.pipe(
  resolver.zod(CreateJob),
  resolver.authorize(),
  async (input, ctx) => {
    const upload = await db.upload.findUnique({
      where: {
        id: input.uploadId,
      },
    });

    if (!upload) throw new NotFoundError();
    if (upload?.userId !== ctx.session.userId) throw new AuthorizationError();

    const existingJob = await db.job.findFirst({
      where: {
        uploadId: input.uploadId,
        type: input.type,
        status: {
          in: [
            ProcessStatus.QUEUED,
            ProcessStatus.PROCESSING,
            ProcessStatus.COMPLETED,
            ProcessStatus.IDLE,
          ],
        },
        parameters: {
          equals: input.parameters,
        },
      },
    });
    if (existingJob) return existingJob;

    const credits = Math.round(
      (upload.length * 1000) / CREDIT_COST.get(input.type)!
    );

    const job = await db.job.create({
      data: {
        uploadId: input.uploadId,
        type: input.type,
        status: ProcessStatus.QUEUED,
        parameters: input.parameters,
        credits,
      },
    });

    return job;
  }
);
