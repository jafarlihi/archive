import { AuthorizationError, NotFoundError } from "blitz";
import { resolver } from "@blitzjs/rpc";
import db from "db";
import { z } from "zod";

const DeleteJob = z.object({
  id: z.string(),
});

export default resolver.pipe(
  resolver.zod(DeleteJob),
  resolver.authorize(),
  async ({ id }, ctx) => {
    const job = await db.job.findFirst({
      where: {
        id,
      },
      include: {
        upload: true,
      },
    });
    if (!job) throw new NotFoundError();
    if (job.upload.userId !== ctx.session.userId)
      throw new AuthorizationError();
    await db.job.deleteMany({ where: { id } });

    return job;
  }
);
