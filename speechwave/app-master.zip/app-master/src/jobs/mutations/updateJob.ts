import { NotFoundError, AuthorizationError } from "blitz";
import { resolver } from "@blitzjs/rpc";
import db, { ProcessStatus } from "db";
import { z } from "zod";

const UpdateJob = z.object({
  id: z.string(),
  status: z.nativeEnum(ProcessStatus).optional(),
});

export default resolver.pipe(
  resolver.zod(UpdateJob),
  resolver.authorize(),
  async ({ id, ...data }, ctx) => {
    const job = await db.job.findFirst({
      where: {
        id,
      },
      include: {
        upload: true,
      },
    });

    if (!job) throw new NotFoundError();
    if (job.upload.userId !== ctx.session.userId)
      throw new AuthorizationError();

    const updatedJob = await db.job.update({ where: { id }, data });

    return updatedJob;
  }
);
