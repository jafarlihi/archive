import { NotFoundError } from "blitz";
import { resolver } from "@blitzjs/rpc";
import db from "db";
import { z } from "zod";

const GetJob = z.object({
  id: z.string(),
});

export default resolver.pipe(
  resolver.zod(GetJob),
  resolver.authorize(),
  async ({ id }, ctx) => {
    const job = await db.job.findFirst({
      where: {
        id,
      },
      include: {
        upload: true,
      },
    });

    if (job?.upload.userId !== ctx.session.userId) return;

    if (!job) throw new NotFoundError();

    return job;
  }
);
