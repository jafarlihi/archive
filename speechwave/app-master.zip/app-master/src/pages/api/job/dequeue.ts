import { NextApiRequest, NextApiResponse } from "next";
import { Ctx } from "@blitzjs/next";
import nextConnect from "next-connect";
import { api } from "src/blitz-server";
import db, { ProcessStatus } from "db";
import { verifyToken } from "src/core/utils";

const apiRoute = nextConnect({
  onError(error, _req: NextApiRequest, res: NextApiResponse) {
    res.status(500).json({ error: `Internal server error, ${error}` }); // TODO: Remove ${error} after dev
  },
  onNoMatch(req: NextApiRequest, res: NextApiResponse) {
    res.status(405).json({ error: `Method '${req.method}' not allowed` });
  },
});

apiRoute.get(
  api(async (req: NextApiRequest, res: NextApiResponse, ctx: Ctx) => {
    const verifyTokenResult = await verifyToken(req, res, ctx, -1);
    if (!verifyTokenResult) return verifyTokenResult;
    ctx.session.$authorize();

    const job = await db.job.findFirst({
      orderBy: {
        updatedAt: "asc",
      },
      where: {
        status: ProcessStatus.QUEUED,
      },
      include: {
        upload: true,
      },
    });
    if (!job) return res.status(204).end();

    await db.job.update({
      where: {
        id: job.id,
      },
      data: {
        status: ProcessStatus.PROCESSING,
      },
    });

    res.status(200).json(job);
  })
);

export default apiRoute;
