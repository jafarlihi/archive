import { NextApiRequest, NextApiResponse } from "next";
import { invoke } from "@blitzjs/rpc";
import { Ctx } from "@blitzjs/next";
import nextConnect from "next-connect";
import { api } from "src/blitz-server";
import db, { ProcessType } from "db";
import { verifyToken } from "src/core/utils";
import createJob from "src/jobs/mutations/createJob";

const apiRoute = nextConnect({
  onError(error, _req: NextApiRequest, res: NextApiResponse) {
    return res.status(500).json({ error: `Internal server error, ${error}` }); // TODO: Remove ${error} after dev
  },
  onNoMatch(req: NextApiRequest, res: NextApiResponse) {
    return res
      .status(405)
      .json({ error: `Method '${req.method}' not allowed` });
  },
});

apiRoute.get(
  api(async (req: NextApiRequest, res: NextApiResponse, ctx: Ctx) => {
    if (!req.query.id && !req.query.take)
      return res.status(400).json({
        error:
          "'id' or 'take' (and optionally 'skip') query parameter is required",
      });
    if (req.query.id) {
      const verifyTokenResult = await verifyToken(req, res, ctx, undefined);
      if (!verifyTokenResult) return verifyTokenResult;
      ctx.session.$authorize();

      const job = await db.job.findFirst({
        where: {
          id: req.query.id as string,
          upload: {
            userId: ctx.session.userId,
          },
        },
        include: {
          upload: true,
        },
      });
      if (!job) return res.status(204).end();

      return res.status(200).json(job);
    } else {
      const verifyTokenResult = await verifyToken(req, res, ctx, undefined);
      if (!verifyTokenResult) return verifyTokenResult;
      ctx.session.$authorize();

      const jobs = await db.job.findMany({
        where: {
          id: req.query.id as string,
          upload: {
            userId: ctx.session.userId,
          },
        },
        orderBy: {
          createdAt: "desc",
        },
        include: {
          upload: true,
        },
        take: Number(req.query.take), // TODO: Limit take
        skip: Number(req.query.skip) || 0,
      });
      if (!jobs) return res.status(204).end();

      return res.status(200).json(jobs);
    }
  })
);

apiRoute.put(
  api(async (req: NextApiRequest, res: NextApiResponse, ctx: Ctx) => {
    const verifyTokenResult = await verifyToken(req, res, ctx, -1);
    if (!verifyTokenResult) return verifyTokenResult;
    ctx.session.$authorize();

    const id = req.body.id;
    const status = req.body.status;
    const result = req.body.result;

    const job = await db.job.update({
      where: {
        id,
      },
      data: {
        status,
        result,
      },
    });

    return res.status(200).json(job);
  })
);

apiRoute.post(
  api(async (req: NextApiRequest, res: NextApiResponse, ctx: Ctx) => {
    const jobs = req.body.jobs;

    const uploadIds: string[] = [];
    for (const job of jobs) {
      const requiredKeys = ["uploadId", "type"].every((k) =>
        job.hasOwnProperty(k)
      );
      if (!requiredKeys)
        return res
          .status(400)
          .json({ error: "All jobs should have 'uploadId' and 'type' keys" });
      if (!Object.values(ProcessType).includes(job.type))
        return res.status(400).json({
          error: `'type' parameter can only be one of 'TRANSCRIPTION', 'TRANSLATION', 'ENHANCEMENT', or 'SUMMARIZATION'. '${job.type}' was provided.`,
        });
      if (job.type !== ProcessType.TRANSCRIPTION && !job.parameters)
        res.status(400).json({
          error:
            "'TRANSLATION', 'ENHANCEMENT', and 'SUMMARIZATION' job types require 'parameters' key, none was provided.",
        });
      uploadIds.push(job.uploadId);
    }

    const verifyTokenResult = await verifyToken(req, res, ctx, undefined);
    if (!verifyTokenResult) return verifyTokenResult;
    ctx.session.$authorize();

    const userIdFilter =
      ctx.session.role === "ADMIN" ? undefined : { userId: ctx.session.userId };

    const uploads = await db.upload.findMany({
      where: {
        id: {
          in: uploadIds,
        },
        ...userIdFilter,
      },
    });
    if (uploads.length !== uploadIds.length)
      return res
        .status(400)
        .json({ error: "At least one of the provided uploadIds don't exist" });

    const results: any[] = [];
    for (const job of jobs) {
      Object.keys(job)
        .filter((k) => !["uploadId", "type", "parameters"].includes(k))
        .forEach((k) => delete job[k]);
      results.push(await createJob(job, ctx));
    }

    return res.status(200).json(results);
  })
);

export default apiRoute;
