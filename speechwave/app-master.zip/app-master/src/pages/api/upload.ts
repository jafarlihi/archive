import { Ctx } from "blitz";
import { getSession } from "@blitzjs/auth";
import nextConnect from "next-connect";
import multer from "multer";
import { v4 as uuidv4 } from "uuid";
import path from "path";
import db from "db";
import ffmpeg, { FfprobeData } from "fluent-ffmpeg";
import util from "util";
import { NextApiRequest, NextApiResponse } from "next";
import { api } from "src/blitz-server";
import { verifyToken } from "src/core/utils";

// TODO: Convert all files to single audio format and store that instead

const ALLOWED_EXTENSIONS = [
  "3gp",
  "aiff",
  "avi",
  "flac",
  "flv",
  "m4a",
  "mkv",
  "mov",
  "mp3",
  "mp4",
  "ogg",
  "wav",
  "webm",
  "wma",
  "wmv",
];

const upload = multer({
  storage: multer.diskStorage({
    destination: "public/uploads",
    filename: (_req, _file, cb) => cb(null, uuidv4()),
  }),
  // TODO: Filter based on mimetype as well
  fileFilter: function (_req, file, callback) {
    const ext = path.extname(file.originalname).replace(".", "");
    if (!ALLOWED_EXTENSIONS.includes(ext))
      return callback(new Error("Unsupported file extension"));
    callback(null, true);
  },
});

const apiRoute = nextConnect({
  onError(_error, _req: NextApiRequest, res: NextApiResponse) {
    return res.status(500).json({ error: `Internal server error` });
  },
  onNoMatch(req, res) {
    return res
      .status(405)
      .json({ error: `Method '${req.method}' not allowed` });
  },
});

apiRoute.use(upload.array("files"));

const ffprobe = util.promisify(ffmpeg.ffprobe);

apiRoute.post(async (req: NextApiRequest & { files: any }, res) => {
  const session = await getSession(req, res);
  if (!session.userId) return res.status(401);

  const results: { filename: string; uuid: string }[] = [];

  for (const file of req.files)
    results.push({ filename: file.originalname, uuid: file.filename });

  for (const result of results) {
    let duration: number | undefined;
    try {
      duration = (
        (await ffprobe(`public/uploads/${result.uuid}`)) as FfprobeData
      ).format.duration;
      if (!duration)
        return res.status(400).json({
          error: `File ${result.filename} seems corrupted, unable to extract duration`,
        });
      duration = Math.floor(duration * 1000);
    } catch (e) {
      return res.status(400).json({
        error: `File ${result.filename} seems corrupted, unable to extract duration`,
      });
    }

    await db.upload.create({
      data: {
        userId: session.userId,
        name: result.filename,
        uuid: result.uuid,
        length: duration,
      },
    });
  }

  return res.status(200).json(results);
});

apiRoute.get(
  api(async (req: NextApiRequest, res: NextApiResponse, ctx: Ctx) => {
    if (!req.query.id && !req.query.take)
      return res.status(400).json({
        error:
          "'id' or 'take' (and optionally 'skip') query parameter is required",
      });
    if (req.query.id) {
      const verifyTokenResult = await verifyToken(req, res, ctx, undefined);
      if (!verifyTokenResult) return verifyTokenResult;
      ctx.session.$authorize();

      const upload = await db.upload.findFirst({
        where: {
          id: req.query.id as string,
          userId: ctx.session.userId,
        },
        include: {
          jobs: true,
        },
      });
      if (!upload) return res.status(204).end();

      return res.status(200).json(upload);
    } else {
      const verifyTokenResult = await verifyToken(req, res, ctx, undefined);
      if (!verifyTokenResult) return verifyTokenResult;
      ctx.session.$authorize();

      const uploads = await db.upload.findMany({
        where: {
          id: req.query.id as string,
          userId: ctx.session.userId,
        },
        orderBy: {
          createdAt: "desc",
        },
        include: {
          jobs: true,
        },
        take: Number(req.query.take), // TODO: Limit take
        skip: Number(req.query.skip) || 0,
      });
      if (!uploads) return res.status(204).end();

      return res.status(200).json(uploads);
    }
  })
);

export default apiRoute;

export const config = {
  api: {
    bodyParser: false,
  },
};
