import { Suspense, useState } from "react";
import { BlitzPage } from "@blitzjs/next";
import { useMutation, usePaginatedQuery } from "@blitzjs/rpc";
import { Grid, Spacer } from "@nextui-org/react";
import { Upload } from "@prisma/client";
import { useCurrentUser } from "src/users/hooks/useCurrentUser";
import getUploads from "src/uploads/queries/getUploads";
import deleteUpload from "src/uploads/mutations/deleteUpload";
import { SignIn } from "./login";
import UploadZone from "src/core/components/UploadZone";
import UploadTable from "src/core/components/UploadTable";
import ProceedCard from "src/core/components/ProceedCard";
import ExecuteModal from "src/core/components/ExecuteModal";

const ITEMS_PER_PAGE = 10;

const Dashboard = (_props: any) => {
  const [selectedUploads, setSelectedUploads] = useState([]);
  const [uploadTablePage, setUploadTablePage] = useState(0);
  const [executeModalVisible, setExecuteModalVisible] = useState(false);

  const [deleteUploadMutation] = useMutation(deleteUpload);
  const [{ uploads, hasMore: uploadsHasMore }, { refetch: refetchUploads }] =
    usePaginatedQuery(getUploads, {
      orderBy: { id: "desc" },
      skip: ITEMS_PER_PAGE * uploadTablePage,
      take: ITEMS_PER_PAGE,
    });

  const onUploadSuccess = async () => {
    await refetchUploads();
  };
  const deleteUploads = async (uploads: Upload[]) => {
    for (const upload of uploads) await deleteUploadMutation({ id: upload.id });
    await refetchUploads();
    setSelectedUploads([]);
  };

  return (
    <>
      <ExecuteModal
        visible={executeModalVisible}
        setVisible={setExecuteModalVisible}
        selected={selectedUploads}
        setSelected={setSelectedUploads}
      />
      <Grid.Container
        gap={2}
        justify="center"
        style={{ height: "100%", paddingTop: "0px" }}
      >
        <Grid xs={12} style={{ height: "100%", paddingTop: "0px" }}>
          <div style={{ width: "100%" }}>
            <UploadZone onSuccess={onUploadSuccess} />
            <Spacer y={1} />
            <ProceedCard
              selected={selectedUploads}
              deleteUploads={deleteUploads}
              onProceedClick={() => setExecuteModalVisible(true)}
            />
            <UploadTable
              selected={selectedUploads}
              setSelected={setSelectedUploads}
              uploads={uploads}
              page={uploadTablePage}
              setPage={setUploadTablePage}
              hasMore={uploadsHasMore}
              refetchUploads={refetchUploads}
              onProceedClick={() => setExecuteModalVisible(true)}
            />
          </div>
        </Grid>
      </Grid.Container>
    </>
  );
};

const DashboardPage: BlitzPage = (props: any) => {
  const currentUser = useCurrentUser();

  return (
    <Suspense>
      {!currentUser ? <SignIn {...props} /> : <Dashboard {...props} />}
    </Suspense>
  );
};

export default DashboardPage;
