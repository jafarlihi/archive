import { BlitzPage } from "@blitzjs/next";

const Landing = (_props: any) => {
  return <>Landing page content</>;
};

const LandingPage: BlitzPage = (props: any) => {
  return <Landing {...props} />;
};

export default LandingPage;
