import { resolver } from "@blitzjs/rpc";
import db from "db";
import { z } from "zod";

const CreateUpload = z.object({
  name: z.string(),
});

export default resolver.pipe(
  resolver.zod(CreateUpload),
  resolver.authorize(),
  async (input) => {
    const upload = await db.upload.create({ data: input });

    return upload;
  }
);
