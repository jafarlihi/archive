import { NotFoundError, AuthorizationError } from "blitz";
import { resolver } from "@blitzjs/rpc";
import db from "db";
import { z } from "zod";

const DeleteUpload = z.object({
  id: z.string(),
});

export default resolver.pipe(
  resolver.zod(DeleteUpload),
  resolver.authorize(),
  async ({ id }, ctx) => {
    const upload = await db.upload.findFirst({
      where: {
        id,
      },
    });

    if (!upload) throw new NotFoundError();
    if (upload.userId !== ctx.session.userId) throw new AuthorizationError();

    await db.job.deleteMany({
      where: {
        uploadId: id,
      },
    });

    await db.upload.deleteMany({ where: { id } });

    return upload;
  }
);
