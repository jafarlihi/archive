import { resolver } from "@blitzjs/rpc";
import db, { ProcessStatus } from "db";
import { z } from "zod";

const UpdateUpload = z.object({
  id: z.string(),
  name: z.string().optional(),
  transcriptionStatus: z.nativeEnum(ProcessStatus).optional(),
  translationStatus: z.nativeEnum(ProcessStatus).optional(),
  enhancementStatus: z.nativeEnum(ProcessStatus).optional(),
  summarizationStatus: z.nativeEnum(ProcessStatus).optional(),
});

export default resolver.pipe(
  resolver.zod(UpdateUpload),
  resolver.authorize(),
  async ({ id, ...data }, ctx) => {
    const upload = await db.upload.updateMany({
      where: {
        id,
        userId: ctx.session.userId,
      },
      data,
    });

    return upload;
  }
);
