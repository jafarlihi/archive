import { NotFoundError } from "blitz";
import { resolver } from "@blitzjs/rpc";
import db from "db";
import { z } from "zod";

const GetUpload = z.object({
  id: z.string(),
});

export default resolver.pipe(
  resolver.zod(GetUpload),
  resolver.authorize(),
  async ({ id }, ctx) => {
    const upload = await db.upload.findFirst({
      where: {
        id,
        userId: ctx.session.userId,
      },
    });

    if (!upload) throw new NotFoundError();

    return upload;
  }
);
