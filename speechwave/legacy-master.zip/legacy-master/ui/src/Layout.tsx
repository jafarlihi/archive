function Layout(props: any) {
  return (
    <>
      {props.children}
    </>
  );
}

export default Layout;
